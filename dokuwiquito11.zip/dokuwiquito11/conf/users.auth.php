# users.auth.php
# <?php exit()?>
# Don't modify the lines above
#
# Userfile
#
# Format:
#
# login:passwordhash:Real Name:email:groups,comma,separated


ibu:$1$I3U0lp8R$R6RUhrGiYTqC/q67Ow2Lk0:Ibu:pvtakpoper@cringe.com:admin,user
