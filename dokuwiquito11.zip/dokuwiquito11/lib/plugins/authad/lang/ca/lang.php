<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Daniel López Prat <daniel@6temes.cat>
 * @author Pauet <pauet@gmx.com>
 * @author controlonline.net <controlonline.net@gmail.com>
 */
$lang['domain']                = 'Logo Domini';
$lang['authpwdexpire']         = 'La vostra contrasenya caducarà en %d dies, l\'hauríeu de canviar aviat.';
$lang['passchangefail']        = 'Ha fallat el canviar el password. Es possible que no s\'hagi complert la política de passwords';
$lang['userchangefail']        = 'Ha fallat el canvi d\'atributs. Pot ser no tinguis compte amb permisos per fer canvis.';
$lang['connectfail']           = 'Ha fallat la connexió amb servidor l\'Active Directory.';
