<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 */
$lang['userexists']            = 'Ja existeix un altre usuari amb aquest nom.';
