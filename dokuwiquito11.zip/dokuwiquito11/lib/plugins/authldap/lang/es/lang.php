<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Mauricio Segura <maose38@yahoo.es>
 * @author David Roy <davidroyapp@gmail.com>
 */
$lang['connectfail']           = 'LDAP no se puede conectar: %s';
$lang['domainfail']            = 'LDAP no puede encontrar el DN de tu usuario';
