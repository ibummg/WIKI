<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Àngel Pérez Beroy <aperezberoy@gmail.com>
 * @author David Surroca <david.tb303@gmail.com>
 */
$lang['starttls']              = 'Utilitzar connexions TLS?';
$lang['bindpw']                = 'Contrasenya de l\'usuari referit abans.';
