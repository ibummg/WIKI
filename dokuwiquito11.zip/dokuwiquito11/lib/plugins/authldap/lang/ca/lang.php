<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author David Surroca <david.tb303@gmail.com>
 */
$lang['connectfail']           = 'L\'LDAP no s\'ha pogut connectar: %s';
$lang['domainfail']            = 'L\'LDAP no ha trobat el teu nom distingit d\'usuari';
